var link = document.querySelector("link[rel~='icon']")
link.href = "https://business.udemy.com/wp-content/themes/udemy-business-child/images/favicon-32x32.png"
